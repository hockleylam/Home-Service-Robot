#!/bin/sh
xterm -e "roslaunch turtlebot_gazebo turtlebot_world.launch"
